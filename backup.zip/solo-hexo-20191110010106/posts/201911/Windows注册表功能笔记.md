title: Windows注册表功能笔记
date: '2019-11-09 20:37:34'
updated: '2019-11-09 20:37:34'
tags: [Note]
permalink: /articles/2019/11/09/1573303054731.html
---
﻿## 右键菜单

### 新建菜单的顺序

路径：`HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Discardable\PostSetup\ShellNew\Classes`

修改其中后缀名的顺序，然后把ShellNew项目的权限改成非继承的，把`Administrator`，`SYSTEM`，`Administrators`三者的权限都设为完全控制。

### 目录

```
HKEY_CLASSES_ROOT\Directory

Defaulticon：默认的该类文件的显示图标，即我们在文件夹中看到的图标。 
Shell：程序外壳子键 
Shell/open/command：打开该类文件的外壳程序，默认值为相应程序的路径、名称及其参数 
Shell/edit/command：编辑该类文件的外壳程序，默认值为相应程序的路径、名称及其参数 
Shell/print/command：打印该类文件的外壳程序，默认值为相应程序的路径、名称及其参数 
```
## Windows 服务
`local machine\system\current version control\services\`