title: VBox安装MacOS
date: '2019-11-09 20:37:33'
updated: '2019-11-09 20:37:33'
tags: [Note]
permalink: /articles/2019/11/09/1573303053929.html
---
在安装完iso文件之后，在VBox安装目录下执行以下命令

```
VBoxManage setextradata Mac "VBoxInternal/Devices/efi/0/Config/DmiSystemProduct" "iMac11,3"

VBoxManage setextradata Mac "VBoxInternal/Devices/efi/0/Config/DmiSystemVersion" "1.0"

VBoxManage setextradata Mac "VBoxInternal/Devices/efi/0/Config/DmiBoardProduct" "Iloveapple"

VBoxManage setextradata Mac "VBoxInternal/Devices/smc/0/Config/DeviceKey" "ourhardworkbythesewordsguardedpleasedontsteal(c)AppleComputerInc"

VBoxManage setextradata Mac "VBoxInternal/Devices/smc/0/Config/GetKeyFromRealSMC" 1

VBoxManage setextradata Mac VBoxInternal2/EfiGopMode 4

VBoxManage setextradata Mac VBoxInternal2/EfiGraphicsResolution 1440x900

```