title: cmd常用命令
date: '2019-11-09 20:37:34'
updated: '2019-11-09 20:37:34'
tags: [Note]
permalink: /articles/2019/11/09/1573303054147.html
---
```powershell
# 系统休眠模式开关
powercfg -h on
# 休眠（hibernate）
shutdown -h

# 使用其他账户权限来运行命令（run as）
runas /noprofile /user:Administrator cmd
# /noprofile表示无配置文件 /user:选择一个账户 之后再接运行命令 比如cmd 这一条命令相当于用管理员身份打开cmd
```

#### 文件操作

mkdir