title: Windows运行命令
date: '2019-11-09 20:37:32'
updated: '2019-11-09 20:37:32'
tags: [Note]
permalink: /articles/2019/11/09/1573303052924.html
---
﻿lusrmgr 本地用户和组管理
netplwiz 本地账户窗口