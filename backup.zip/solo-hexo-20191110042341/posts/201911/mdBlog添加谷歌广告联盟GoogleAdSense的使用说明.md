title: md-Blog 添加谷歌广告联盟 Google AdSense 的使用说明
date: '2019-11-10 04:13:28'
updated: '2019-11-10 04:13:28'
tags: [Note]
permalink: /articles/2019/11/10/1573330408371.html
---
> 官网：https://www.google.com/adsense/

0、特别注意，此功能需科学上网。
1、点击上方官网链接注册账号。
2、到手机验证码填写这一步可能会出现以下错误：
`Invalid phone number. Please check your phone number and try again.`
或者：
`电话号码无效。请检查您的电话号码,然后再试一次。`
这里格式需要特别注意：格式为 `+86 138 xxxx-xxxx`
![IMAGE](resources/F13A87C25DA37418C8315D87D4C134D5.jpg =392x309)

3、注册好之后，进入填写您的网站地址，复制红框内代码。
![IMAGE](resources/2F01C1598AD4D85BB6E5DA5E71F3ECEB.jpg =1557x814)
4、进入md-Blog 后台：http://www.您的网站地址.com/set/

![IMAGE](resources/DF5189A72D93D666C27E0A2B300E2121.jpg =559x288)
开启谷歌广告联盟Google AdSense功能，粘贴到下方脚本代码处。
5、点击`保存`按钮：
![IMAGE](resources/6FADAE243E8906B3016B2208590D12EC.jpg =398x53)
6、最后点击`全站静态生成`按钮：
![IMAGE](resources/44AA260009F0FF29C60EEF77D9FE001C.jpg =399x67)
7、返回Google Adsense后台点击`大功告成`按钮进行代码验证：
![IMAGE](resources/6E8D49EEEDABAB2639355CD2779F5BD3.jpg =722x524)
8、之后需等待审核完成账号的添加。
![IMAGE](resources/6898F9B7526EE017ADE70547C870E060.jpg =677x261)