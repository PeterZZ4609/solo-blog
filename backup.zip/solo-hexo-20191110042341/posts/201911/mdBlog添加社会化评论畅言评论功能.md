title: md-Blog 添加社会化评论-畅言评论功能
date: '2019-11-10 04:13:29'
updated: '2019-11-10 04:13:29'
tags: [Note]
permalink: /articles/2019/11/10/1573330409632.html
---
> 您的博客/网站如需启用畅言功能，请在 `畅言后台` → `系统设置` → `通用设置` → `基本设置` 进行ICP备案提交，否则只能使用15天。

# 1、畅言后台操作

1、注册/登录畅言 http://changyan.kuaizhan.com/
2、新建站点
3、在数据总览下查看畅言密匙 http://changyan.kuaizhan.com/overview
![IMAGE](resources/8209BC803713E2EA5AC691498B69DBF2.jpg =715x173)

#2、md-Blog 后台操作

1、进入控制台
2、在畅言评论设置一栏开启功能
![IMAGE](resources/3B8F002D2C81101600462E2E7952FD78.jpg =447x132)
3、填入对应的畅言密匙
![IMAGE](resources/53195307B7DBD8990BC19AF2D2A2EE91.jpg =613x222)
4、保存
5、 静态生成
6、添加成功后每篇博客会增加对应的评论模块
![IMAGE](resources/9726F74EE2D73E6DEF4A55365F3077F6.jpg =822x264)