title: md-Blog 码农专用 Fork me on Github 彩带设置
date: '2019-11-10 04:13:29'
updated: '2019-11-10 04:13:29'
tags: [Note]
permalink: /articles/2019/11/10/1573330409350.html
---
进入 md-Blog 后台，填入您的 GitHub 地址，选择你喜欢的彩带颜色，保存。

![IMAGE](resources/10C67D326788FA783FC64286A113261C.jpg =466x166)

提供以下几种供选择：
![IMAGE](resources/224AE5B48F1094A5815D9B5074D83F19.jpg =103x660)