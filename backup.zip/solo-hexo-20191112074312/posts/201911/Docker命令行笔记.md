title: Docker命令行笔记
date: '2019-11-10 20:42:20'
updated: '2019-11-10 20:42:20'
tags: [Docker, 命令行, 版本控制]
permalink: /articles/2019/11/10/1573389740308.html
---
## Docker 命令行笔记

```bash
# 查看正在运行的容器
docker ps
# 查看所有容器
docker ps -a

# 删除容器
docker rm 容器ID
# 删除镜像
docker rmi 镜像ID
```