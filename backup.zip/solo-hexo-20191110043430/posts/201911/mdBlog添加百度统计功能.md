title: md-Blog 添加百度统计功能
date: '2019-11-10 04:13:28'
updated: '2019-11-10 04:13:28'
tags: [Note]
permalink: /articles/2019/11/10/1573330408068.html
---
#1、百度统计后台操作

1、访问百度统计地址：https://tongji.baidu.com/ 注册/登录账户。
2、打开 `管理` → `网站列表` → `自有网站` → `新增网站`。
![IMAGE](resources/93120CBBDD59AB7973A3CEBABF15D88B.jpg =707x235)
![IMAGE](resources/82480A0D1D367051ADB7475DAB9A0A2A.jpg =133x56)
![IMAGE](resources/78FA369FC5E2E97268FD203ADF11FF57.jpg =520x422)
3、点击获取代码
![IMAGE](resources/900C6043B12B201891887551695B761C.jpg =343x110)
4、复制代码框中的内容
![IMAGE](resources/AADE3D76B31679EF7407319B6CBDAEA2.jpg =827x290)

#2、md-Blog 后台操作

1、进入控制台
2、在百度统计一栏开启功能
![IMAGE](resources/5165E7578ACCF4511522A19539A0E891.jpg =475x166)
3、粘贴代码到脚本代码框中
![IMAGE](resources/9913D23228F12DB4ED4B321E39AB5EAB.jpg =557x295)
4、保存
5、静态生成
6、添加成功后，博客侧边栏会出现一个百度统计超链接，指向百度统计登录官网，方便统计访客数据。
![IMAGE](resources/DE895A27D81E4AD087534571EAF308E3.jpg =292x132)