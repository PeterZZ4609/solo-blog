title: 常用 MarkDown 编辑器推荐
date: '2019-11-10 04:13:29'
updated: '2019-11-10 04:13:29'
tags: [Note]
permalink: /articles/2019/11/10/1573330409078.html
---
> md-Blog 博客系统是不支持 MarkDown 编辑的，术业有专攻，我们推荐以下几款 MarkDown 编辑器供客户选择。

# MarkdownPad
官网：http://www.markdownpad.com/
平台：Windows
![IMAGE](resources/32408AC1FDAFB5BA1A27CF3B7D7AE01F.jpg =1001x718)

# Quiver
官网：http://happenapps.com/
平台：Mac、iOS
![IMAGE](resources/E83C404ECE78CC1D81165F0B58761712.jpg =1199x697)
此款为鄙人常用软件，虽然移动端体验差点儿，程序员必备可一键导出资源，贴图方便直接复制粘贴即可，支持各种cell，`md-Blog` 支持其导出的 MarkDown 文件及图片资源。把生成的目录直接上传到 `md-Blog` 系统生成博客即可。

# Mou
官网：http://25.io/mou/
平台：Mac

![IMAGE](resources/F9F42EAFC1110E0FC998FC5F64CBB367.jpg =929x643)
这个不用多说，直接肝。

# MWeb
官网：http://25.io/mou/
平台：Mac、iOS
![IMAGE](resources/E65D0CD6FB56DFA61F80B028079A8154.jpg =927x692)
也是一款笔记类型的MarkDown编辑器和 `Quiver` 有的一拼，移动端颇受好评。

# 印象笔记
官网：https://www.yinxiang.com/
平台：Mac、Windows、Android、iOS
![IMAGE](resources/36A7642DF969F2870042DE374B5E5EEB.jpg =1522x713)
都8102年了，印象笔记终于支持 MarkDown 语法了。

# 码农编辑器
插件需要自己安装
宇宙第一的 `Visual Studio Code`
官网：https://code.visualstudio.com/
平台：Windows x64、Mac、Linux x64
![IMAGE](resources/D18AEC69CA9D4F6E2950437C50921EC9.jpg =1167x583)
  
情怀第一 `Sublime`
官网：http://www.sublimetext.com/
平台：Windows、Mac、Linux
![IMAGE](resources/35FBEF161C2AA5364A262F073EE8828F.jpg =1239x754)

GitHub 倾力之作 `Atom`
官网：https://atom.io/
平台：Windows、Mac、Linux
![IMAGE](resources/BFF839810F7A33FAB19E377863A84917.jpg =909x715)