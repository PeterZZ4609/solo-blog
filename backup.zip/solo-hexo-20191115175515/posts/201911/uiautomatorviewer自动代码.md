title: uiautomatorviewer自动代码
date: '2019-11-10 20:27:23'
updated: '2019-11-10 20:27:23'
tags: [Note]
permalink: /articles/2019/11/10/1573388842981.html
---
# uiautomatorviewer 自动代码

## 起源

这个uiautomatorviewer是网上找的包，有些小问题，后面还有博主自己稍微优化的简易版本，需求简单的可以稍后用后面优化的uiautomatorviewer.jar。

文件下载：

[LvmamaXmlKit.jar](https://www.lanzous.com/i73mbtc)

[uiautomatorviewer.jar](https://www.lanzous.com/i73mbsb)

## 使用方法

### 1. 备份并替换 uiautomatorviewer.jar

`sdk根目录\tool\lib`下，有一个 `uiautomatorviewer.jar`或者带着sdk版本号的如 `uiautomatorviewer-26.0.0-dev.jar`

将它备份然后把我们下载的 `uiautomatorviewer.jar`改成对应的名称放到lib目录里

![1572522788990](https://pics.peterzhang.top/mdpics/Other/SoftTest/uiautomatorviewer自动代码.md/157252278899.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

### 2. 向手机推送 LvmamaXmlKit.jar

手机连接电脑，使用`adb devices`确认手机USB调试正常连接。

然后用以下命令推送文件：

```
adb push E:\LvmamaXmlKit.jar /data/local/tmp
```

adb命令的第二个参数 `E:\LvmamaXmlKit.jar` 就是要推送的本地文件路径。

### 3. 完成

启动 uiautomatorviewer 即可。

![1572523803948](https://pics.peterzhang.top/mdpics/Other/SoftTest/uiautomatorviewer自动代码.md/157252380394.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

*Tips: 右边框框的代码是可以连续生成的；由于作者没有给源代码，博主找了jar反编译工具搞到的代码也乱糟糟的，没有成功修改右侧生成的代码，还请自行使用 `Ctrl + F` 批量替换**findElement**为**findElementById**或**findElementByXPath**，然后把该方法的第二个参数如“id”、“xpath”删掉；如果觉得这样麻烦你也可以仅仅使用Node Detail表中自动生成的xpath；另外还有其他玩法自行探索。*

## 小优化

文件下载：

[LvmamaXmlKit.jar](https://www.lanzous.com/i73mbtc)（这个和上面那个是一样的）

[博主的uiautomatorviewer.jar](https://www.lanzous.com/i73md2h)

这个 `uiautomatorviewer.jar` 是我用别人二开源码稍作修改（应该会有后续更新），右侧没有代码框，右键点击是**模拟点击**，会发送点击命令到手机并刷新屏幕快照，我做的只是把Node Detail中的xpath和resource-id的内容加上了 `driver.findElementByXPath("xxxx").click()`以及 `driver.findElementById("xxxx").click()`。

![1572525248768](https://pics.peterzhang.top/mdpics/Other/SoftTest/uiautomatorviewer自动代码.md/157252524876.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

尽情享用吧，希望能有大佬分享一下更好的二开版本源码。

[项目源码（GitHub）](https://github.com/PeterZZ4609/uiautomatorviewer-peter)