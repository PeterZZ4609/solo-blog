title: Appium环境搭建
date: '2019-11-10 20:27:23'
updated: '2019-11-10 20:27:23'
tags: [Appium, 环境搭建]
permalink: /articles/2019/11/10/1573388843329.html
---
# Appium 环境搭建

## 注意：

文中所有的使用cmd或者run或者双击直接运行的命令（或程序），都需要管理员权限，因为有的命令（或程序）它不会自己申请管理员权限，但它需要，唉。。。

- 如何打开具有管理员权限的cmd：（`Win+R`，“cmd”，不要按回车，按`Ctrl+Shift+回车`）

- 如何让一个程序拿到管理员权限再启动：右击这个程序，选择“以管理员身份运行”，像Eclipse这种经常需要打开而又需要管理员权限的程序，你可以右击->属性->兼容性->以管理员身份运行（打勾）->确定。

*Tip：Eclipse安装插件要使用管理员权限，这是俺踩的坑。。。*

*Tip：安卓手机的USB调试在手机的“开发人员选项”中，这个设置页面默认不开放，你可以去设置中找到能够显示你手机配置信息的那个页面，然后找那个跟手机搭载的系统相关的那条信息连续点击几次，比如说我的小米，那么应该找到 `MIUI版本`这条，华为的应该就是 `EMUI版本`，或者一般手机可能会叫“软件版本(号)”，实在不行就挨个点咯。。。还要注意各种手机给USB调试设置的保护措施，你打开了USB调试，但连上电脑之后手机还是没反应，也许是“仅充电模式不允许USB调试”等*

*Tip：如何检查手机是否已经以USB调试模式连接电脑：cmd下输入adb devices（等配置完安卓的环境变量才可以哦），List of devices attached下面有那么一条xxxxxxxx device就可以了，xxxxxxxx offline或者xxxxxxx unauthorized都不行，一个是离线了，拔了重插，一个是未授权，拔了重插，注意在手机上弹出的小窗，点击允许这台电脑调试该手机*

## 环境变量：

> 当要求系统运行一个程序而没有告诉它程序所在的完整路径时，系统除了在当前目录下面寻找此程序外，还应到path中指定的路径去找。

比如我运行 `tim`命令（Win+R），如下：

![1569632052295](https://pics.peterzhang.top/mdpics/Other/SoftTest/Appium环境搭建.md/156963205229.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

有可能你觉得会报错，然而系统除了会发现这个命令没有完整路径而不能锁定文件位置外，它还会去环境变量里面找找有没有这么一条命令，而我的环境变量 `Path` 里面已经有这么一条：`E:\run`，那么它会找到的，你看：

![1569632168559](https://pics.peterzhang.top/mdpics/Other/SoftTest/Appium环境搭建.md/156963216855.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

准确来说，这条命令应该是 `Tim.lnk`，因为这是一个快捷方式嘛，但 Windows 很聪明啊，像 `*.lnk`，`*.exe`，这种可执行的命令，它不会在意你有没有加上后缀。

当你明白了这个好玩的事情，你就可以像我一样把自己的程序快捷方式大仓库配置到环境变量里面，然后跟我一起：`Win+R`，“tim”，回车！要记得快捷方式的名字要改得简单点。

### 好了言归正传

> Node.js 是一个基于 Chrome V8 引擎的 [JavaScript](https://baike.baidu.com/item/JavaScript/321142) 运行环境。 Node.js 使用了一个事件驱动、非阻塞式 I/O 的模型。
> Node 是一个让 JavaScript 运行在[服务端](https://baike.baidu.com/item/服务端/6492316)的开发平台，它让 JavaScript 成为与[PHP](https://baike.baidu.com/item/PHP/9337)、[Python](https://baike.baidu.com/item/Python/407313)、[Perl](https://baike.baidu.com/item/Perl/851577)、[Ruby](https://baike.baidu.com/item/Ruby/11419) 等服务端语言平起平坐的[脚本语言](https://baike.baidu.com/item/脚本语言/1379708)。发布于2009年5月，由Ryan Dahl开发，实质是对Chrome V8引擎进行了封装。
> Node对一些特殊用例进行优化，提供替代的[API](https://baike.baidu.com/item/API/10154)，使得V8在非浏览器环境下运行得更好。V8引擎执行Javascript的速度非常快，性能非常好。Node是一个基于Chrome JavaScript运行时建立的平台， 用于方便地搭建响应速度快、易于扩展的网络应用。Node 使用[事件驱动](https://baike.baidu.com/item/事件驱动/9597519)， 非阻塞[I/O](https://baike.baidu.com/item/I%2FO/84718) 模型而得以轻量和高效，非常适合在分布式设备上运行数据密集型的实时应用。

Appium 是一个由`node.js`（由js语言写成的一个名叫node的框架，就像前端里面的`jQuery`，`Vue`等，编写框架的程序员让所有程序员的开发更容易，感谢他们）开发的进行软件测试的软件，它依赖于node.js，所以你把它安装到电脑上的时候，它需要知道哪里能运行node命令来支撑它自己，so，环境变量啊。

如下图：

![1569633147337](https://pics.peterzhang.top/mdpics/Other/SoftTest/Appium环境搭建.md/156963314733.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

`Appium\node_modules\.bin`这个文件夹包含了Appium命令，配置了环境变量，你可以在cmd中（`Win+R`，“cmd”，回车！在cmd中输入命令和在Run窗口中输入命令的区别是，Run窗口其实是调用cmd的，但它调用完会把cmd窗口关掉，而Appium这个窗口主要是用来看日志的，所以你懂了吧）使用Appium命令，开启Appium。

好了现在Appium可以启动了。对于我们要进行的安卓应用测试，还需要谷歌官方提供的软件开发包来支持测试。

![1569631263835](https://pics.peterzhang.top/mdpics/Other/SoftTest/Appium环境搭建.md/156963126383.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

首先在外层环境变量新建一条 `ANDROID_HOME`，你看它是大写的，`public static final`的变量也是要全大写的，所以你可以理解为这是一条全局常量，供`Path`里的环境变量来调用，它的值是你解压的android-sdk目录。

判断你配置的目录正确性的方法是，这个目录下要有这些东西：

![1569633538885](https://pics.peterzhang.top/mdpics/Other/SoftTest/Appium环境搭建.md/156963353888.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

这样我觉得你不会搞错了（不，我并不是很自信）。

然后同理，在 `Path`里面配上这两条带有 `ANDROID_HOME`的环境变量：

![1569633760388](https://pics.peterzhang.top/mdpics/Other/SoftTest/Appium环境搭建.md/156963376038.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

你应该也发现咯，常量名两边加个%就表示对它的引用了。

### 这样的话

三中环境变量都配置好了，打开cmd用这几条命令测试一下系统知不知道它们的位置：

![1569633905888](https://pics.peterzhang.top/mdpics/Other/SoftTest/Appium环境搭建.md/156963390588.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

（cmd中按两下`Ctrl+C`可以退出node的命令行，一般程序是一次`Ctrl+C`）

![1569634200773](https://pics.peterzhang.top/mdpics/Other/SoftTest/Appium环境搭建.md/156963420077.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

![1569634160977](https://pics.peterzhang.top/mdpics/Other/SoftTest/Appium环境搭建.md/156963416097.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

![1569634283609](https://pics.peterzhang.top/mdpics/Other/SoftTest/Appium环境搭建.md/156963428360.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

看起来，像 `uiautomatorviewer`这种不用加额外参数的命令是可以直接双击运行的，嗯。。。

接下来是Eclipse安装慕测插件、使用慕测插件生成的MoocTest下载题目包，写脚本，连接手机（USB调试）、运行脚本。

这些内容请参照Q群中的pdf文件：

![1569635146331](https://pics.peterzhang.top/mdpics/Other/SoftTest/Appium环境搭建.md/156963514633.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

感谢参阅！

联系我：QQ 1809909143，mob 13912151813，或 [www.peterzhang.top](www.peterzhang.top) 评论留言。

知识改变世界，分享的知识改变全世界，我是小政子。