title: Python内置类型
date: '2019-11-10 05:41:48'
updated: '2019-11-10 05:41:48'
tags: [Note]
permalink: /articles/2019/11/10/1573335707952.html
---
﻿# Python 内置类型

## 序列

容器序列

- `list`
- `tuple`
- `collections.deque`

扁平序列

- `str`
- `bytes`
- `bytearray`
- `memoryview`
- `array.array`

其中 `tuple`，`str`，`bytes` 是不可变序列，其余的几个都是可变的。

![1569301066758](https://pics.peterzhang.top/mdpics/Python/Python内置类型.md/156930106675.png?imageView2/0/format/webp/interlace/1/q/75|watermark/2/text/cGV0ZXJ6aGFuZy50b3A=/font/5b6u6L2v6ZuF6buR/fontsize/500/fill/I0FGQUZBRg==/dissolve/80/gravity/SouthEast/dx/10/dy/10|imageslim)

### list（列表）

#### 基础内容

创建：

```python
# 赋值
list1 = []
list2 = [1,2,3,"a","s","d"]

# 构造函数 list(可序列化类型)
list1 = list()
list2 = list([2,3,4])
list3 = list(range(2,10))  # range(a,b)左闭右开 [a,b)==[a,b-1]
list4 = list("Demacia")  # --> ["D","e","m","a","c","i","a"]
list5 = [0] * 100  # 这是列表的复制
```

list 支持下标访问，拼接用 `+`，复制用 `*`；

遍历：

```python
for el in range(0, len(list0))
for el in list0:
# 只读访问
```

使用 `in`/`not in`判断某元素在不在list中，返回 `True`或 `False`

关系运算符（ <、>、==、<=、>=、!= ）可用于列表的比较（逐个元素进行比较）

```python
# 列表比较时是逐项进行比较，如果比较不同类型元素会报错：
list1 = [1, 2, 3]
list2 = ["a", "as", "a"]
print(list1 > list2)
# TypeError: '>' not supported between instances of 'int' and 'str'

list1 = [1, 2, 3]
list2 = [2, "as", "a"]
print(list1 > list2)
# False
```

切片：

```python
list0[start:end:step]  #  可读可写
# start >= end 返回空列表
# end比列表长度还大时，切片自动截取到最后一个元素
list0[a:]  # [a:len(list0)]
list0[:b]  # [0:b]
list0[len(list0):] = [1,2,3,4,5] # 等价于↓
list0 = list0 + [1,2,3,4,5]
```

#### 列表推导式

一个栗子：

```python
list0 = [x * x for x in range(1,11)]
# [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
```

#### 生成器表达式

一个栗子：

```python
list0 = list((lambda: random.randint(0, 100))() for i in range(0, 20))
print(list0)
# [49, 45, 7, 51, 91, 93, 31, 48, 89, 29, 4, 54, 2, 54, 33, 29, 77, 63, 21, 94]


def func(x):
    return x ** 2

list1 = list(func(x) for x in range(0, 8))
print(list1)
# [0, 1, 4, 9, 16, 25, 36, 49]

```

如果生成器表达式不使用 `list()`进行转换的话，控制台将输出以下内容：

`<generator object <genexpr> at 0x000002254D542248>`

#### list 成员函数

```python
list.append(x)
list.extend(list L)
# 拼接
list.insert(index,x)
# 前插元素
list.remove(x)
# 删掉列表中第一个x,如果找不到x则报错，😂居然会报错
list.pop(i=len(list)-1)
# 弹出i位置元素，默认弹走最后一个（假装自己是堆栈）
list.index(x)
# 返回第一个x的下标，没有就报错（怎么又报错
list.count(x)
# 看看x出现了几次
list.reverse()
# 倒置列表
```

### tuple（元组）

`tuple`不可变。

#### 基础内容

创建：

```python
import random

# 一般
tuple0 = ()
tuple0 = (1, 2, 3)

# 单元素元组的创建
tuple1 = (1,)

# 构造函数
tuple2 = tuple([1, 2, 3])
tuple0 = tuple()

# 生成器表达式
tuple2 = tuple(
    (lambda: random.randint(0, 100))() for i in range(10)
)
```

元组的自动封装与序列拆封

```python
x, y, z = 1, 2, 3
x, y, z = (2, 3, 4)
(x, y, z) = 3, 4, 5
(x, y, z) = (4, 5, 6)
```



### 集合

集合是没有顺序的一堆数据，就像在数学里一样，集合中不能有相同的对象

此外，集合存储的对象必须是**可哈希的**

## 附：可迭代对象（iterable）函数

```python
len(s)
# 用于序列或集合，返回对象的元素个数
all(iterable)
# 如果对象中每个元素均为True则返回True，否则返回False
any(iterable)
# 如果对象中每个元素均为False则返回False，否则返回True
max(iterable), min(iterable)
# 返回最大值/最小值
sorted(iterable,cmp=None,key=None,reverse=False)
# 排序
sum(iterable,start=0)
# 求和
```