title: Git命令
date: '2019-11-10 05:41:49'
updated: '2019-11-10 05:41:49'
tags: [Note]
permalink: /articles/2019/11/10/1573335709688.html
---
```bash
# 查看public key
cat ~/.ssh/id_rsa.pub

# 生成新的密钥
ssh-keygen -t rsa -b 4096 -C "xxxxxxx@xx.com"

git config --global user.name "PeterZhang4609"
git config --global user.email "5185881+peterzhang4609@user.noreply.gitee.com"

cd d:/workspace
mkdir newDir
cd newDir

// 初始化仓库
git init

// 新建文件
touch xxx
git add xxx


git commit -m"xxxxxx comment"
git push -u origin master

// 查看远程仓库
git remote -v

// 删除未经跟踪的文件
git clean -f
```