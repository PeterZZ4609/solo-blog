title: MySQL命令行执行sql文件的两种方法
date: '2019-11-10 05:41:49'
updated: '2019-11-10 05:41:49'
tags: [Note]
permalink: /articles/2019/11/10/1573335709191.html
---
## MySQL命令行执行sql脚本文件

### 方法一：

1. 使用 `mysql -u用户名 -p`，输入密码登入数据库；

2. 使用 `use 数据库名`切换数据库；

3. 使用 `source sql文件路径`或 `\. sql文件路径`执行脚本

### 方法二：

```
mysql -u用户名 -p密码 -D数据库名<sql文件路径
```

*Tip：可以从sql文件所在目录启动命令行，这样就不用输入完整路径了。*