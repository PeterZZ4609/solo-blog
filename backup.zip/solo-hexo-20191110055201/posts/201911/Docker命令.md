title: Docker命令
date: '2019-11-10 05:41:49'
updated: '2019-11-10 05:41:49'
tags: [Note]
permalink: /articles/2019/11/10/1573335709457.html
---
```bash
# 查看正在运行的容器
docker ps
# 查看所有容器
docker ps -a

# 删除容器
docker rm 容器ID
# 删除镜像
docker rmi 镜像ID
```