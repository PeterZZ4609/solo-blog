title: Windows系统文件列表
date: '2019-11-09 20:37:33'
updated: '2019-11-09 20:37:33'
tags: [Note]
permalink: /articles/2019/11/09/1573303053486.html
---
A　

ACCESS.CHM - Windows帮助文件

ACCSTAT.EXE - 辅助状态指示器

ADVAPI32.DLL - 高级Win32应用程序接口

AHA154X.MPD - SCSI驱动程序

AM1500T.VXT - 网卡驱动程序

AM2100.DOS - 网卡驱动程序

APPSTART.ANI - 动画光标

APPS.HLP - Windows帮助文件

AUDIOCDC.HLP - "易码编码解码器"帮助文件

AWARDPR32.EXE - 增加打印机工具

B　

BIGMEM.DRV - BIGMEM虚拟设备

BILLADD.DLL - 动态链接库(支持MSW)

BIOS.VXD - 即插即用BIOS接口

BUSLOGIC.MPD - SCSI驱动程序

C　

CALC.EXE - 计算器应用程序

CANNON800.DRV - 佳能打印机驱动程序

CHOICE.COM - MSDOS命令

CHS16.FON - 字体文件(16点阵中文)

CANYON.MID - MIDI文件例子

CARDDRV.EXE - PCMCIA支持程序

CDFS.VXD - CDROM文件系统

CDPLAYER.EXE - CD播放器应用程序

CDPLAYER.HLP - CD播放器帮助文件

CHIPS.DRV - 芯片技术显示驱动程序

CHKDSK.EXE - DOS磁盘检查工具

CHOOSUSR.DLL - 网络客户

CHOKD.WAV - 声音文件例子

CIS.SCP - 脚本文件(演示如何建立与Compuserve的PPP连接)

CLAIRE~1.RMI - MINI序列

CLIP.INF - 安装信息文件(剪粘板查看器)

CLOSEWIN.AVI - 影片剪辑(AVI)(如何关闭窗口)

CMC.DLL:Mail - API1.0公共信息调用

COMBUFF.VXD - COM端虚拟设备

COMCTL32.DLL - 32位Shell组件

COMDLG32.DLL - 32位公共对话库

COMIC.TIF - TrueType字体文件(Comic Sans Ms)

COMMAND.COM - 公共对话库

COMMDLG.DLL - 16位公共对话库

COMMON.HLP - OLE帮助文件

COMPOBJ.DLL - OLE16/32互*作库

CONAGEN.EXE - 32位控制支持

CONFAPI.DLL - Microsoft网络组件

CONFIG.SYS - 配置文件

CONFIG.TXT - 自述文件(配置文件中如何使用命令)

CONTROL.EXE - "控制面板"应用程序

COOL.DLL - 统一资源定位文件

COPY.INF - 安装信息文件

CP-1250.NLS - 自然语言支持文件

CPQNDIS.DOS - 网卡驱动程序

CPQNDIS3.VXD - Compaq以太控制器NDIS驱动程序

CR3240.EXE - DOS6.22中文版CR3240打印机驱动程序

CRTDLL.DLL - Microsoft C运行时间库

CSETUP.EXE - MSDOS6.22中文设置程序

CSETUP.WIN - CSetup.exe支持文件

CSMAPPER.SYS - 系统文件(支持PCMCIA)

CSPMAN.DLL - 动态链接库(SoundBlaster 16 Driver)

CTRLPAN.EXE - MSDOS命令(系统控制台程序)

CTRLPAN.EXE - MSDOS6.22中文版控制程序



D　

DBLBVFF.SYS - 双缓冲驱动程序

DC21X4.SYS - NDIS3驱动程序

DCIMAN.DLL - 显示控制接口

DCIMAN32.DLL - 显示控制接口

DDEML.DLL - DDE信息库

DEBMP.DLL - 光栅显示设备

DEBUG.EXE - Debug调试工具

DECPSMW4.INF - 安装信息文件(DEC打印机安装)

DECLAN.VXD - DECLAN网卡驱动程序

DEFRAG - 打开"选定驱动器"窗口

DEL.INF - 安装信息文件

DELTEMP.COM - 初始化帮助工具

DELTREE.EXE - 删除目录工具

DEMET.DLL - 向量显示工程

DESKCP16.DLL - 16位桌面控制面板

DESKTOP.MSN - Microsoft网络组件

DESS.DLL - 表格显示工程

DEWP.DLL - 字处理



显示工程

DIALER.CNT - 对话帮助

DIALER.EXE - 电话拨号程序

DIALER.HLP - 电话拨号帮助文件

DIALMON.EXE - 拨号监视程序(IE2.0)

DIBENG.DLL - 独立设备的位同工程

DICONIX.DRX - 打印机驱动

非常棒哦^__^.WAN - 声音文件例子

DIRECTCC.EXE - 直接线缆连接应用程序

DISKCOMP - 磁盘比较工具

DISKCOPY.COM - 磁盘拷贝工具

DISKDRV.INF - 安装信息

DISPLAY.TXT - 显示卡README文件

DMCOLOR.DLL - 通用打印驱动程序彩打支持库

DOSKEY.COM - DOS命令

DOSX.EXE - MSDOS配置程序

DRAGDROP.AVI - 影片剪辑(AVI)(如何使用拖拽)

DRIVER.SYS - DOS驱动程序

DRVSPACE.EXE - 磁盘压缩工具

DRVSPACE.HLP - 磁盘空间管理帮助文件



E　

EDIT.COM - DOS文字编辑程序

EDLIN.EXE - DOS行编辑器

EE16.VXD - 虚拟设备驱动程序

EISA.VXD - 即插即用EISA总线计数器

EK550C.ICM - 打印机简介

EMM386.EXE - 扩展内存管理程序

ENABLE.INF - 初始化信息

ENGCT.EXE - MSN支持文件

ESCP24SC.DRV - 设备驱动程序

EUDCEDIT.CNF - 帮助索引文件(造字程序)

EUDCEDIT.EXE - 造字程序

EUDCEDIT.HLP - 帮助文件(造字程序)

EUDCEDIT.INF - 安装信息文件(造字程序)

EVX16.DOS - 网卡驱动程序

EWRK3.DOS - 网卡驱动程序

EWRK3.SYS - 网卡驱动程序

EXCEL.XLS - Excel5.0文件模板

EXCEL4.XLS - Excel4.0文件模板

EXCHANGE.TXT - Inbox和Exchange的自述文件

EXCHNG.CNT - Mail/Exchange帮助文件内容

EXCHNG.HLP - Mail/Exchange组件

EXCHNG32.EXE - 对用户的交换机作初始设置

EXPLORER.AVI - 影片剪辑(AVI)(如何使用资源管理器)

EXPLORER.EXE - "资源管理器"应用程序

EXPO.HLP - 帮助文件(产品信息)

EXPOSTRT.EXE - 产品信息应用程序

EXTRACT.EXE - 解压缩工具

EXTRA.TXT - 自述文件(联机访问附加文件)



F　

FAQ.TXT - 疑难解答自述文件

FAXCODEC.DLL - 传真编码/译码器

FAXCOVER.EXE - 封面编辑器

FC.EXE - DOS命令,比较两个文件

FD16-700.MPD - SCSI驱动程序

FD8XX.MPD - SCSI驱动程序

FDISK.EXE - DOS命令,在硬盘上建立、删除及显示当前分区

FILESEC.VXD - 文件存取控制管理器

FILEXFER.CNT - 文件传输帮助文件内容

FILEXFER.EXE - Microsoft文件传输

FIND.AVI - 影片剪辑(如何使用查找)

FIND.EXE - 寻找指定字符串命令

FINDMVI.DLL - 媒体视觉支持

FINSTALL.DLL - 字库安装程序

FINSTALL.HLP - 字库安装帮助文件

FLSIMTD.VXD - PCMCIA支持

FLSIMTD.VXD - PCMCIA支持

FONT16.EXE - DOS6.22中文版16点阵字体驱动程序

FONTS.INF - 字体选择初始化信息

FONTVIEW.EXE - 字体浏览程序

formAT.COM - DOS磁盘格式化工具

FOUTLINE.EXE - 轮廓字体驱动程序

FRAMEBUF.DRV - SVGA显示器驱动程序

FTE.DLL - 声音浏览文件传输工程文件

FTP.EXE - 文件传输协议TCP工具

FURELI~1.RMI - MINI序列

G　

GBK.TXT - 中文Windows95GBK代码集字符定义表





GDI.EXE - 简版WIN3.1图形界面

GDI32.DLL - 32位GDI图形界面

GENERAL.IDF - 一般MIDI指示器

GRPCONV.EXE - Windows程序组转换器

GUIDE.EXE - 应用程序(MSN)



H　

HARDWARE.TXT - 硬件自述文件

HOSTS.SAM - TCP配置

HPCLRLSK.ICM - 打印简介

HPDESK.ICM - 打印机简介表

HPDSKJET.DRV - 打印机驱动程序

HPEISA.VXD - 网络适配器驱动程序

HPJAHLP.CNT - JetAdmin程序帮助文件

HPJD.DLL - HPJetAdmin支持程序

HPLAN.DOS - 网络适配器驱动程序

HPLJ300.DRV - HPLJ300DPI打印机驱动程序

HPLJ300.EXE - MSDOS命令(HP打印机驱动)

HPLJ-31.SPD - 打印机驱动程序

HPLJ600.DRV - HPLJ600DPI打印机驱动程序

HPLJP-V4.INF - 打印机安装信息

HPNETPRN.INF - HPJetAdmin支持程序

HPPJXL31.SPD - 打印机驱动程序

HPPLOT.DRV - 打印机驱动程序

HPPLOT.HLP - 打印机驱动程序帮助文件

HPPRARBK.DLL - HPJetAdmin支持程序

HPPRARRK.HLP - HPJetAdmin支持程序帮助文件

HPVCM.HPM - 打印机驱动程序

HSFLOP.PDR - HSFLOP虚拟设备

HTICONS.DLL - 终端设备动态链接库

HYPERTRM.CNT - 终端设备帮助文件

HYPERTRM.EXE - 终端设备应用程序

HYPERTRM.HLP - "超级终端"帮助

HZKBD.EXE - 常用输入方法程序

HZVIO95.EXE - 显示驱动程序

I　

I82593.DOS - 网络适配器驱动程序

IB401917.SPD - 打印机驱动程序

IBM20470.SPD - 打印机驱动程序

IBM20K.DOS - 网络适配器驱动程序

ICM32.DLL - 图象颜色匹配程序

ICMOI.DLL - 用户界面颜色匹配程序

ICONLIB.DLL - 图符库

IEXPLORE.CNT - 帮助索引文件(IE)

IEXPLORE.EXE - InternetExplore

IEXPLORE.HLP - 帮助文件(IE)

IFSHLP.SYS - 文件系统安装帮助文件

IFSMGR.VXD - 文件系统安装管理程序

IMAGEOIT.EXE - 图象编辑器光标程序

IMCLIENT.DLL - Microsoft网络组件

IME.CNT - 帮助索引文件(中文输入法)

IME.HLP - Windows帮助文件

IME.INF - 安装信息文件(中文输入法)

IMEGEN.CNF - 帮助索引文件(输入法生成器)

IMEGEN.EXE - 输入法生成器

IMEGEN.HLP - 帮助文件(输入法生成器)

IMEINFO.INI - 输入法初始化文件

IMM32.DLL - WIN32IMM应用程序界面

INBOX.EXC - 邮件组件

INDICDLL.DLL - 多语言组件

INET.TXT - IE自述文件

INET16.DLL - 动态链接库(支持IE2.0)

INETAB32.DLL - 动态链接库(支持Internet mail)

INETCFG.DLL - 动态链接库(支持IE2.0)

INETCPL.CPL - 控制面板文件(配置IE2.0)

INETMAIL.INF - 安装信息文件(Internet mail)

INETWIZ.EXE - Internet安装向导

INformS.WPF - 样板文件

INSTBE.BAT - Microsoft网络组件

INSTDICT.EXE - MSDOS命令(输入法安装程序)

INTB.VXD - 13号中断虚拟设备

INTL.CPL - 控制面板

INT-MAIL.CNT - 帮助索引文件(Internet mail)

IOS.INI - 设置需要安全保护的程序

IOSCLASS.DLL - CDROM安装程序

IRMATR.DOS - 网络适配器驱动程序

ISAPNP.VXD - ISA总线即插即用程序

　

JOY.CPL -



游戏杆控制面板

JOYSTICK.INF - 多媒体安装信息

JP350.DRV - 打印机驱动程序

JUNGLE~1.WAV - 声音文件



K　

KBDBE.KBD - 比利时键盘格式

KBDBR.KBD - 巴西键盘格式

KBDCA.KBD - 法国、加拿大键盘格式

KBDOS.KBD - 美国键盘格式

KDCOLOR1.SPD - 打印机驱动程序

KERNEL32.DLL - 32位内核

KEYB.COM - 将控制键盘程序装入内存

KODAKCE.ICM - 柯达ICC配置文件

KRNL386.EXE - Core应用程序



L　

LABEL.EXE - DOS命令,设置磁盘名称

LFNBK.EXE - 长文件名备份文件

LFNBK.TXT - LFNBK的自述文件

LICENSE.HLP - Windows帮助文件

LMSCRIPT.EXE - LAN管理器文稿处理程序

LOGIN.EXE - Win95登录NetWare文件

LQ1600K.EXE - LQ1600K打印驱动程序



M　

MAILMSG.DLL - 微软网络组件

MAILOPT.INF - MAIL/MAPI设置文件

MAPI.DLL - Mail/Exchange组件

MCIAVI.DRV - 多媒体驱动程序

MCICDA.DRV - MCICD声音驱动程序

MCIOLE.DLL - MCIOLE句柄

MCIPIONR.DRV - MCI光盘驱动程序

MCISEQ.DRV - MCI定序器驱动程序

MCIVISCA.DRV - MCIVCR驱动程序

MCIWAVE.DRV - MCI Ware驱动程序

MDMNOKIA.INF - 安装信息文件(modem)

MDMNOVA.INF - 安装信息文件(modem)

MDMVV.INF - 安装信息文件(modem)

MEMMAKER.EXE - 内存管理程序

MEMMAKER.INF - 内存管理程序设置信息

MFCUIA32.DLL - OLEI公共对话动态链接库

MIDI.INF - 即插即用MIDI设备信息

MINET32.DLL - 支持Internet Mail动态链接库

MKECR5XX.MPD - SCSI驱动程序

ML3XEC16.EXE - 应用程序(MAPI)

MLSHEXT.DLL - 微软核扩展库

MMCI.DLL - 媒体类安装程序

MMDEVLDR.VXD - 即插即用设备装载程序

MMDRV.HLP - 多媒体帮助文件

MMSOUND.DRV - 多媒体驱动程序

MMSYSTEM.DLL - 多媒体系统内核

MMTASK.TSK - 多媒体背景任务交换器

MODE.COM - DOS命令

MODERN.FON - 字体文件(modem)

MORE.COM - DOS命令

MOUSE.DRV - 鼠标驱动程序

MOVEWIN.AVI - 影片剪辑(如何移动窗口)

MPLAYER.EXE - 媒体播放程序

MPR.DLL - WIN32网络接口动态链接库

MSAB32.DLL - 微软网络地址簿

MSBASE.INF - 设置信息

MSCDEX.EXE - DOS MSCDEX CDROM扩展工具

MSCDROM.INF - 类安装设置信息

MSD.EXE - 微软诊断工具

MSD.INI - 微软诊断初始化

MSDET.INF - 系统检测设置信息

MSDISP.INF - 显示设置信息

MSDLG.EXE - 数据链接控制协议

MSDOS.INF - 设置信息

MSDOSDRV.TXT - 设备驱动程序自述文件

MSFT.VRL - 统一资源定位文件

MSGSRV32.EXE - Windows32位虚拟设备信息系统

MSHDC.INF - 硬盘控制设置信息

MSJSTICK.DRV - 即插即用游戏杆驱动程序

MSMAIL.INF - Mail/MAPI初始化

MSMOUSE.INF - 鼠标设置信息

MSN.TXT - 微软网络自述文件

MSNET32.DLL - 微软32位网络API库

MSNEXCH.EXE - 微软网络设置程序

MSNPSS.HLP - 微软网络帮助文件

MSNVER.TXT - 微软网络帮助信息

MSPAINT.EXE - 画图工具

MSPCIC.DLL - PCMCIA类安装与控制工具





MSPORTS.INF - 公共设置信息

MSPP32.DLL - 微软网络打印支持程序

MSPWL32.DLL - 口令清单管理库

MSSBLST.DRV - 声霸卡驱动程序

MSSBLSI.VXD - 声霸卡驱动程序

MSSHRVI.DLL - 共享内核扩展程序

MSSNDSYS.DRV - Windows声音系统驱动程序

MSSP.VXP - Windows NT安全支持

MSTCP.DLL - TCP用户界面

MSVIEWUT.DLL - 显示设备服务数据链接库

MTMMINIP.MPD - SCSI驱动程序

MULLANG.INF - 多种语言字体支持设置信息

MVIWAVE.DRV - 声音驱动程序



N　

NBTSTAT.EXE - TCP工具

NDDEAPI.DLL - Workgroups DDE共享接口

NDDENB.DLL - 微软网络DDE NetBIOS接口

NDISHLP.SYS - 实模式NDIS支持驱动程序

NET.EXE - 实模式网络客户软件

NET.INF - 网络检测信息

NET.MSG - 网络客户信息

NET3COM.INF - 网络设置信息

NETAMD.INF - 网络设置信息

NETAPI.DLL - 网络应用程序接口动态链接库

NETAPI32.DLL - 32位网络API动态链接库

NETAVXT.INF - MS内部传输文件

NETBEUI.VXD - 32位NetBEUI协议

NETBIOS.DLL - NetBIOSAPI库

NETDCA.INF - 安装信息文件

NETDDE.EXE - Windows网络动态数据交换

NETDET.INI - NetWare检测文件

NETDI.DLL - 网络设备安装

NETH.MSG - 网络客户帮助信息

NETOS.DLL - NOS检测DLL

NETWATCH.EXE - 网络观测程序

NETWORK.TXT - 网络信息自述文件

NOTEPAD.EXE - 记事本应用程序

NODRIVER.INF - 即插即用设备信息

NOTEPAD.EXE - NOTEPAD文件

NSCL.VXD - NSCL虚拟设备

NW16.DLL - NetWare客户

NWAB32.DLL - 地址簿支持动态链接库

NWLSCON.EXE - 登录文稿控制台程序

NWLSPROC.EXE - NetWare登录处理器

NWNET32.DLL - NetWare客户

NWNP32.DLL - NetWare组件

NWREDIR.VXD - NetWare重定向

NWSERVER.VXD - NCP服务

NWSP.VXD - NCP服务安全提供



O　

OEMREVA.INF - 安装信息文件

OLE2.DLL - OLE2.0动态链接库

OLE2.INF - OLE设置信息

OLE32.DLL - 32位OLE2.0组件

OLEAUT32.DLL - OLE2-32自动化

OLECL1.DLL - 对象链接与嵌入客户库

OLEDLG.DLL - Windows OLE2.0用户接口支持

OLESVR.DLL - 对象链接与嵌入服务端库

OLETHK32.DLL - OLE形实替换程序库



P　

PACKAGER.EXE - 对象包装程序

PARALINK.VXD - 远程网络存取并行口驱动程序

PBRVSH.EXE - "画图"应用程序

PDOS95.BAT - 进入中文DOS状态

PERF.VXD - 系统性能监视器

PIFMGR.DLL - 程序信息文件管理服务程序

PING.EXE - TCPPing工具

PMSPL.DLL - LAN管理应用程序接口

POWER.DRV - 高级电源管理驱动程序

PPPMAC.VXD - Windows虚拟PPP驱动程序

PRINT.EXE - DOS打印文件

PRINTERS.TXT - 打印信息自述文件

PROGMAN.EXE - 程序管理器

PRTVPD.INF - 打印机升级设置信息



Q　

QUIKVIEW.EXE - 快速查看

QUIT.EXE - 退出中文DOS状态

R　

README.TXT - Windows95自述文件

REGEDIT.EXE - 注册编辑器

REGSERV.EXE - 远程注册

REGWIE.EXE - 注册工具

REGSERV.INF - 远程注册

RESTORE.EXE - DOS



命令

RNAAPP.EXE - 拨号网络应用程序

RNASERV.DLL - 远程网络存取服务

RNASETUP.DLL - 远程网络存取设置动态链接库

RNATHUNK.DLL - 远程网络存取转换支持动态链接库

RNAUI.DLL - 远程网络存取用户接口DLLRNDSRV32.DLL复制服务程序

ROBOTZCL.WAV - 声音文件

ROBOTZWI.WAV - 声音文件

ROMAN.FON - 字型文件

ROUTE.EXE - TCP/IP ROUTE命令

RPCLTC1.DLL - 远程调用库

RPCNS4.DLL - 远程调用库

RPCPP.DLL - 远程调用打印驱动

RPCRT4.DLL - 远程调用库

RPCSS.EXE - 远程调用结点映象

RPLBOOT.SYS - 远程程序装入

RPLIMAGE.DLL - 远程程序装入磁盘映象器

RSRC16.DLL - 资源计量器

RSRCMTR.EXE - 资源计量器

RSRCMTR.INF - 资源计量器

RUMOR.EXE - DDE测试/游戏

RUNDLL.EXE - 把DLL作为应用程序运行

RUNDLL32.EXE - 32位壳组件

S　

S3.DRV - S3显示驱动

S3.VXD - S3虚拟设备

SACLIEN.DLL - Microsoft网络组件

SAMPLEVIDEOS - 图象文件

SAPNSP.DLL - Winsock数据连接库

SAVE32.COM - 安装时所需的TSR文件

SB16.VXD - 16位声卡虚拟设备

SB16SND.DRV - 16位声卡驱动

SBAWE.VXD - AWE声卡虚拟设备

SBAWE32.DRV - AWE声卡驱动

SBFM.DRV - 16位声卡驱动

SCANDISK.BAT - MSDOS6.x Scandisk的替代存根模块SCANDISK.BAT磁盘诊断工具

SCANDISK.INI - 磁盘诊断工具

SCANDISK.PIF - 安装磁盘诊断工具时的PIF文件

SCANDSKW.EXE - 磁盘扫描工具

SCANPROG.EXE - 磁盘扫描工具

SCRNSAVE.SCR - 屏幕保护

SCSI.INF - SCSI安装文件文件名描述

SCSIIHLP.VXD - SCSI支持文件

SCSIPORT.PDR - SCSI虚拟设备口

SECUR32.DLL - Microsoft Win32安全服务

SECURCL.DLL - Microsoft网络组件

SEIKO24E.DRV - 打印机驱动

SEIKOSH9.DRV - 打印机驱动

SERIAL.VXD - 串口VCOMM驱动器

SERIFE.FON - 字型文件

SERVER.HLP - 服务器帮助文件

SETMDIR.EXE - SBS文件

SETUP.BIN - 安装支持文件

SETUP.BMP - 安装Wash位图文件

SETUP.EXE - Windows95安装程序

SETUP.INF - 安装信息文件

SETUP.TXT - 安装时的README文件

SETUP4.DLL - 安装支持文件

SETUPPP.INF - 安装信息

SETUPX.DLL - 安装支持

SETVER.EXE - MSDOS版本显示,该程序可在网络上执行

SF4029.EXE - 打印机驱动

SHARE.EXE - MSDOS共享实用程序

SHELL.INF - 安装壳信息

SHELL.VXD - 虚拟壳设备

SHELL2.INF - 颜色组合

SHELL3.INF - 颜色组合

SIZE1-1.CUR - 光标

SIZE1-M.CUR - 光标

SIZE4-M.CUR - 光标

SIZENESW.ANI - 活动光标

SIZEWE.ANI- 活动光标

SKPSFA-1.SPD - 打印机驱动

SLAN.DOS - 网络适配器驱动

SLCD32.MPD - SCSI驱动器

SLENH.DLL - 高级节能选项

SMALLE.FON - 字型文件

SMALLF.FON - 字型文件

SMARTDRV.EXE - 超高速缓存程序

SMARTND.DOS - 网络适配器驱动器

SMC3000.DOS - 网络适配器驱动器

SMC9000.VXD - 网络适配器驱动器

SNAPSHOT.EXE - 抽点

SNAPSHOT.VXD - 抽点虚拟设备

SNDREC32.EXE - 录音机

SNI



P.VXD - 网络适配驱动器

SOCKET.VXD - Windows虚拟Socket网卡驱动器SOCKET.VXD PCMCIA支持

SOL.CNT - 纸牌游戏

SOL.HLP - 纸牌游戏帮助文件

SORT.EXE - MSDOS分类实用程序

SOUNDREC.CNT - 录音机帮助文件内容

SOUNDREC.HLP - 录音机帮助文件

SPARROW.WPD - SCSI驱动器

SPARROWX.MPD - SCSI驱动器

SPOOL32.EXE - 打印机支持

SPOOLER.VXD - 打印机共享虚拟设备

SRAMMTD.VXD - PCMCIA支持

SSERIFE.FON - 字型文件

SSERIFF.FON - 字型文件

SSFLYWIN.SCR - 屏幕保护

SSSTARS.SCR - 屏幕保护

STAR24E.DRV - 打印机驱动

STAR9E.DRV - 打印机驱动

START.EXE - 启动程序

STATE.PBK - Microsoft网络组件

STDOLE.TLB - OLE2.0文件

STDOLE32.TLB - OLE2-32文件

STEMO409.DLL - Windows95帮助文件的DLL

STLSO4SS.SPD - 打印机驱动程序

STLS577U.SPD - 打印机驱动程序

STORAGE.DLL - OLE存储器管理库

STRN.DOS - 网络适配器驱动

SUBST.EXE - MSDOS Subst实用程序

SUEXPAND.DLL - LZ DLL安装

SUHELPER.BIN - 安装支持

SUPERVGA.DRV - 高级VGA显示驱动

SURPORT.TXT - PSS支持信息

SVCPROP.DLL - Microsoft网络组件

SVRAPI.DLL - 32位公用服务器API实用程序

SXCIEXT.DLL - Matrox显示驱动支持文件

SYMBOLE.FON - 字型文件

SYS.COM - MSDOS系统实用程序

SYSCLASS.DLL - 系统类库安装

SYSDETMG.DLL - 系统检测库

SYSEDIT.EXE - 系统编辑器

SYSLOGO.RLE - 系统标识

SYSMON.EXE - 系统监控程序

SYSMON.HLP - 系统监控帮助

SYSTEM.DRV - 最小Win3.1标准模式

SYSTHUNK.DLL - Windows系统形实替换程序库

SYSTRAY.EXE - 高级节能管理



T　

T128.MPD - SCSI驱动器

T160.MPD - SCSI驱动器

T20N3.VXD - 网络适配驱动器

T30ND.DOS - 网络适配驱动器

T338.MPD - SCSI驱动器

TADA.WAV - 声音文件

TAPI.DLL - API通话程序

TAPI.INF - API通话安装信息文件

TAPI32.DLL - 32位形实替换

TAPIADDR.DLL - API通话程序

TAPIEXE.EXE - API通话组件

TAPIINI.EXE - API通话组件

TASKMAM.EXE - 任务管理器

TCCARC.DOS - 网络适配驱动器

TCTOKCH.VXD - 网络适配驱动器

TELEPHON.CPL - 通话帮助

TESTPS.TXT - PostScript测试

TEXTCHAT.EXE - Microsoft网络组件

THEMIC-1.WAV - 声音文件

THINKJET.DRV - 打印机驱动

THREED.VBX - Windows95浏览

T1850.DRV - 打印机驱动

TIMEDATE.CPL - 时间/日期控制面板

TIMES.TTF - 时间字型

TIMESBD.TTF - 时间粗体字型

TIMESBI.TTF - 时间粗斜体字型

TIMESI.TTF - 时间斜体字型

TIMEZONE.INF - 安装信息

TIMLP232.SPD - 打印机驱动

TIPS.txt - 提示和技巧自述文件

TKPHZR32.SPD - 打印机驱动

TLNK.DOS - 网络适配驱动器

TLNK3.VXD - 网络适配驱动器

TMV1.MPD - SCSI驱动器

TOOLHELP.DLL - 16位开发工具帮助器

TOSHIBA.DRV - 打印机驱动

TOUR.EXE - 浏览文件

TPHAIII.ICM - 打印机简介

TRACERT.EXE - TCP/IP IRACEROUTE命令

TREE.COM - MS DOS树实用程序

TREEEDCL.D



LL - Microsoft网络组件

TREENVCL.DLL - Microsoft网络组件

TRIUMPHI.SPD - 打印机驱动

TSD32.DLL - 声音压缩管理器

TSENG.DRV - ET4000W32显示驱动

TTY.DRV - 打印机驱动

TTY.HLP - TTY打印机驱动帮助

TYPELIB.DLL - OLE2.0



U　

U9415470.SPD - 打印机驱动

UBNEI.DOS - 网络适配器驱动

ULTRA124.MPD - SCSI驱动器

ULTRA24F.MPD - SCSI驱动器

UMDM16.DLL - 通用调制解调器驱动组件

UMDM32.DLL - 通用调制解调器驱动组件

UNIDRV.DLL - Microsoft通用打印机驱动库

UNIDRV.HLP - 通用打印机驱动帮助

UNIMODEM.VXD - 通用调制解调器驱动

USER32.DLL - 32位用户



V　

V86MMGR.VXD - V86MMGR虚拟设备

VCACHE.VXD - VCache虚拟设备

VCD.VXD - 虚拟COM驱动程序

VCOMM.VXD - VCOMM驱动程序

VCOND.VXD - Win32控制台

VDMAD.VXD - VDMAD虚拟设备

VER.DLL - 小型Win3.1安装程序16位版动态链接库

VER.NEW - 版本检测与文件安装库

VERSION.DLL - 32位版本动态链接库

VERX.DLL - 安装程序使用的版本动态库

VFAT.VXD - VFAT文件系统

VFD.VXD - 软盘虚拟设备

VFLATD.VXD - 虚拟平板帧缓存虚拟设备

VGA.DRV - VGA显示驱动程序

VIDCAP.INF - 即插即用VCD信息

VIDEOT.VXD - 视频虚拟设备

VIP.386 - TCP/IP虚拟IP设备

VJOYD.VXD - 游戏棒虚拟设备

VKD.VXD - 虚拟键盘设备

VLB32.DLL - Mail/Exchange组件

VMD.VXD - Win3.1虚拟鼠标驱动程序

VMM.VXD - 虚拟存储管理设备

VMM32.VXD - 虚拟存储管理设备

VMOUSE.VXD - 虚拟鼠标驱动程序

VNBT.386 - NetBIOS传输驱动程序

VNETBIOS.VXD - VNETBIOS虚拟设备

VNETSUP.VXD - 网络支持虚拟设备

VPD.VXD - 虚拟LPT驱动程序

VPICD.VXD - 虚拟可编程干扰控制器设备

VPOWERD.VXD - 高级电源管理虚拟设备

VREDIR.VXD - Microsoft网络32位客户端程序

VSAMI.DLL - AMI文件语法分析程序

VSASC8.DLL - ASCII文件语法分析程序

VSBMP.DLL - BMP文件语法分析程序

VSERVER.VXD - Microsoft网络32位服务器端程序

VSGIF.DLL - GIF文件语法分析程序

VSHARE.VXD - 32位共享虚拟设备驱动程序

VSMSW.DLL - Win写文件语法分析

VSPP.DLL - PowerPoint语法分析程序

VSRTF.DLL - RTF文件语法分析程序

VSTIFF.DLL - TIFF文件语法分析程序

VSW6.DLL - Word6文件语法分析程序

VSWORD.DLL - Word文件语法分析程序

VSWP5.DLL - WordPerfect5文件语法分析程序

VSXL5.DLL - Excel文件/图表语法分析程序

VTCP.386 - TCP/IP虚拟TCP驱动程序

VTDAPI.VXD - VTDAPI虚拟设备

VTDI.386 - 传输驱动接口支持程序

VXDLDR.VXD - 虚拟设备驱动程序装载器



W　

WAVE.INF - 即插即用音波设备信息

WDTOOOEX.MPD - SCSI驱动

WGPOADMN.DLL - Mail/Exchange组件

WHLP16T.DLL - 帮助动态链接库

WIN87EM.DLL - 80387数学仿真库

WINABC.HLP - 智能ABC帮助文件

WINBX.HLP - 表形码输入法帮助文件

WINCHA.HLP - 繁体仓颉输入法帮助文件





WINDOWS.CNT - Windows95帮助文件内容

WINDOWS.HLP - Windows95帮助文件

WINFILE.CNT - 文件管理器帮助文件内容

WINFILE.EXE - Windows工作组文件管理器

WINFILE.HLP - 文件管理器帮助文件

WINGB.HLP - 区位码输入法帮助文件

WINHLP23.HLP - Windows帮助文件

WINIME.HLP - *作指南帮助文件

WINNM.HLP - GBK内码输入法帮助文件

WININIT.EXE - Windows初始化文件

WINIPCFG.EXE - TCP/IP配置工具

WINNEWS.TXT - Winnews信息

WINPHO.HLP - 繁体注音输入法帮助文件

WINPOPUP.EXE - POPUP工具

WINREG.DLL - 远程注册支持

WINPY.HLP - 全拼输入法帮助文件

WINSOCK.DLL - Windows的套接API

WINSY.HLP - 双拼输入法帮助文件

WINXSP.HLP - GBK双拼输入法帮助文件

WINXZM.HLP - GBK郑码输入法帮助

WINZM.HLP - 郑码输入法帮助文件

WNASPI32.DLL - Windows DLL32位ASPI

WPSUNI.DRV - 传真驱动程序

WPSUNIRE.DLL - WPS主机资源执行程序



X　

XCOPY.EXE - DOS XCOPY工具

XCOPY32.EXE - 文件拷贝程序

XGA.DRV - XGA显示驱动程序